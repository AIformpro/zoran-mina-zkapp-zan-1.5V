from __future__ import annotations
import argparse, json, hashlib, pathlib, datetime

def make_receipt(path: str, budgets: dict, author_pubkey: str | None) -> dict:
    p = pathlib.Path(path)
    src = p.read_text(encoding="utf-8", errors="ignore")
    lu = hashlib.sha256((src + "|HG1.5V").encode()).hexdigest()
    proof_mock = hashlib.sha256(("POV|" + lu + "|" + json.dumps(budgets, sort_keys=True)).encode()).hexdigest()
    return {
        "lu_hash": lu,
        "budgets": budgets,
        "proof": {"kind":"mock-sha256","value":proof_mock},
        "author_pubkey": author_pubkey or "",
        "ts": datetime.datetime.utcnow().isoformat()+"Z"
    }

def parse_kv_list(items):
    out={}
    for it in items or []:
        if "=" in it:
            k,v = it.split("=",1)
            try:
                out[k]=int(v) if v.isdigit() else float(v)
            except Exception:
                out[k]=v
    return out

def main(argv=None):
    ap = argparse.ArgumentParser(prog="hgzk")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("receipt")
    p.add_argument("path")
    p.add_argument("--budgets", nargs="*")
    p.add_argument("--author-pubkey")
    args = ap.parse_args(argv)
    if args.cmd=="receipt":
        rec = make_receipt(args.path, parse_kv_list(args.budgets), args.author_pubkey)
        print(json.dumps(rec, indent=2))

if __name__=="__main__":
    main()
