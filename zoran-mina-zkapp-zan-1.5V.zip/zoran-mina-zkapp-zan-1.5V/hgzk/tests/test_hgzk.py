from hgzk.cli import make_receipt

def test_receipt():
    r = make_receipt("../examples/hello.hg", {"time_ms":50}, None)
    assert "lu_hash" in r and "proof" in r
