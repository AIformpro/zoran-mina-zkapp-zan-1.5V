import { Field, SmartContract, state, State, method, UInt64, PublicKey } from "o1js";
export class ZoranZkApp extends SmartContract {
  @state(Field) rootLU = State<Field>();
  @state(Field) rootUsage = State<Field>();
  @state(UInt64) epoch = State<UInt64>();
  @state(UInt64) rewardRate = State<UInt64>();
  init(){ super.init(); this.rootLU.set(Field(0)); this.rootUsage.set(Field(0)); this.epoch.set(UInt64.from(0)); this.rewardRate.set(UInt64.from(1000)); }
  @method registerLU(luHash: Field, proofHash: Field){ this.rootLU.set(this.rootLU.get().add(luHash).add(proofHash)); }
  @method submitUsage(usageRoot: Field){ this.rootUsage.set(usageRoot); }
  @method mintZAN(miner: PublicKey, workHash: Field, amount: UInt64){ amount.assertLte(this.rewardRate.get()); this.rootUsage.set(this.rootUsage.get().add(workHash)); }
}
