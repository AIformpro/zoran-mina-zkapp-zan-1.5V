import { Field, UInt64, PublicKey } from "o1js";
import { ZoranZkApp } from "./zkapp.js";
async function main(){ const app = new ZoranZkApp(); app.init(); app.registerLU(Field(123), Field(456)); app.submitUsage(Field(789)); app.mintZAN(PublicKey.empty(), Field(111), UInt64.from(10)); console.log("ZoranZkApp demo finished."); }
main();
